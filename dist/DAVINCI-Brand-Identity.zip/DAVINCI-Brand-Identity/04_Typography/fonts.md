# الخطوط · Typography

جميع الخطوط من Google Fonts وبرخصة SIL Open Font License — مجانية للاستخدام التجاري.
All typefaces are Google Fonts under the SIL Open Font License — free for commercial use.

## A — Codex · الدفتر
- **Amiri** — Arabic · headline & body — https://fonts.google.com/specimen/Amiri
- **Cormorant Garamond** — English · headline & body — https://fonts.google.com/specimen/Cormorant+Garamond
- **IBM Plex Mono** — Annotations & dimensions — https://fonts.google.com/specimen/IBM+Plex+Mono

## B — Model · النموذج
- **IBM Plex Sans Arabic** — Arabic · headline & body — https://fonts.google.com/specimen/IBM+Plex+Sans+Arabic
- **Space Grotesk** — English · headline & body — https://fonts.google.com/specimen/Space+Grotesk
- **IBM Plex Mono** — Data, layers, dimensions — https://fonts.google.com/specimen/IBM+Plex+Mono

## C — Monolith · الكتلة
- **Alexandria** — Arabic · headline, body & figures — https://fonts.google.com/specimen/Alexandria
- **Syne** — English · headline & body — https://fonts.google.com/specimen/Syne

## Frame of the presentation
- IBM Plex Sans / IBM Plex Sans Arabic / IBM Plex Mono

قواعد: العربية دائماً من اليمين لليسار، ولا تُباعد حروفها أبداً. الاسم يُكتب «دافنشي» فقط.
Rules: Arabic is always right-to-left and never letter-spaced. The name is spelled «دافنشي» only.
