# DAVINCI · دافنشي — الهوية البصرية الكاملة / Complete brand identity

مكتب دافنشي للاستشارات الهندسية — استكشاف الهوية البصرية بثلاثة اتجاهات كاملة.
DAVINCI Engineering Consultancy — brand identity exploration, three complete directions.

| | الاتجاه · Direction | الأنسب لـ · Best for |
|---|---|---|
| A | الدفتر · Codex | الفلل والمنازل الفاخرة والتصميم المعماري · Villas, luxury homes, architecture |
| B | النموذج · Model — **موصى به · recommended** | المطوّرون والمقاولون والجهات الحكومية وBIM · Developers, contractors, government, BIM |
| C | الكتلة · Monolith | مطوّرو العقارات الراقية · High-end real-estate developers |

## محتويات الحزمة · Contents

| المجلد · Folder | المحتوى · What's inside |
|---|---|
| `01_Identity-Book/DAVINCI-Identity-Book.pdf` | كتاب الهوية كاملاً (29 صفحة) مع فهرس — Full identity book (29 pages) with bookmarks |
| `01_Identity-Book/DAVINCI-Presentation.html` | العرض التفاعلي (يُفتح في المتصفح، يحتاج إنترنت للخطوط) — Interactive presentation (open in a browser; needs internet for fonts) |
| `02_Logos/<A,B,C>/SVG` | الشعارات بصيغة متجهة، النصوص محوّلة لمسارات — Vector logos, type outlined |
| `02_Logos/<A,B,C>/PDF` | للطباعة والمطابع — For print shops (vector) |
| `02_Logos/<A,B,C>/PNG` | خلفية شفافة 512 / 1024 / 2048 — Transparent PNG |
| `02_Logos/<A,B,C>/favicon` | أيقونات الموقع والتطبيق 16–512 + favicon.ico — Web & app icons |
| `03_Colours` | الألوان HEX / RGB / CMYK بصيغ JSON و CSS و TXT + لوحات النسب — Palettes + proportion sheets |
| `04_Typography/fonts.md` | الخطوط وروابطها وقواعد الاستخدام — Typefaces, links, rules |
| `05_Mockups` | التطبيقات بدقة عالية: لوحة الموقع، بطاقة العمل، تقرير الدفعة، إنستغرام، الورق الرسمي، الخوذة والسترة + المقارنة — High-res application mockups + comparison |
| `06_Screenshots` | لقطات كل الأقسام: سطح المكتب 1440 والجوال 375 — Every section, desktop & mobile |
| `PLAN.md` | الهندسة الدقيقة لبناء كل رمز — Exact geometry of each symbol |

## أنواع الشعار · Logo versions

- **symbol** — الرمز وحده · symbol only
- **symbol-small** — نسخة الأحجام الصغيرة (32 بكسل وأقل) · small-size master (≤ 32 px)
- **horizontal** — أفقي: DAVINCI | الرمز | دافنشي · bilingual horizontal lockup
- **stacked** — عمودي · stacked lockup
- **light** — للخلفيات الفاتحة · for light backgrounds
- **dark** — للخلفيات الداكنة (شفاف بألوان فاتحة؛ ملف PDF بخلفية داكنة للمعاينة) · for dark backgrounds

## ملاحظات · Notes

- بيانات الاتصال والأسماء والمشروع في النماذج افتراضية (0770 000 0000 ، davinci-eng.iq) — Contact details, names and project in the mockups are placeholders.
- قيم CMYK نقطة بداية؛ تُعتمد بعد بروفة طباعة — CMYK values are starting points; confirm with a press proof.
- الخطوة التالية: اختيار اتجاه واحد ← جولة تطوير ← دليل الهوية النهائي وتسليم الملفات.
  Next: choose one direction → refinement round → final guidelines and file delivery.
